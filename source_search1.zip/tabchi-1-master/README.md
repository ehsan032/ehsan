# Tabchi V1.0
ادیت شده توسط یونیکر تیم

## نحوه نصب
```bash
git clone https://github.com/uniquer-tm/tabchi-1.git && cd tabchi && chmod 777 install.sh && chmod 777 uniquer.sh && ./install.sh && lua creator.lua
```
## ساخت ربات!
```
lua creator.lua
Auto Detected Tabchi ID : 0
Enter Full Sudo ID : شناسه خودتان
Done!
New Tabchi Created...
ID : 0
Full Sudo : شناسه شما
Run : ./tabchi-0.sh
```
شما میتوانید شناسه عددی خودرا از @USERinfoBot در تلگرام دریافت کنید

## راه اندازی
برای راه اندازی دستور 
./tabchi-id.sh
دریافت کردید بزنید(Auto Detected Tabchi ID)ایدی که در قسمت(id)را باید بزنید که به جای

## روشن بودن خودکار
برای اتو لانج یا روشن بودن خودکار دستور زیر را وارد کنید در پوشه تبچی
./uniquer.sh

#### channel      [Uniquer_Tm](https://telegram.me/Uniquer_Tm)

